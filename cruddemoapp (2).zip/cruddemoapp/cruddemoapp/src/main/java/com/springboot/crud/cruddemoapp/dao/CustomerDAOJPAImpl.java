package com.springboot.crud.cruddemoapp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.springboot.crud.cruddemoapp.entity.Customer;

@Repository
public class CustomerDAOJPAImpl implements CustomerDAO {
	
	
	private EntityManager entityManager;
	
	@Autowired
	public CustomerDAOJPAImpl(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	@Transactional
	public List<Customer> findAll() {

		//create query
		Query theQuery=entityManager.createQuery("from Customer");
		
		//execute query and get result set
		List<Customer> customers=theQuery.getResultList();
		
		//return resultset
		return customers;
	}

	@Override
	@Transactional
	public Customer findById(int theId) {
		
		//get the customer 
		//in JPA ,we use find() instead of get()
		Customer customer=entityManager.find(Customer.class, theId);
		
		//return the customer
		return customer;
	}

	@Override
	public void save(Customer customer) {
		
		//in JPA ,we use merge() instead of save()
		Customer dbCustomer=entityManager.merge(customer);
		
		customer.setId(dbCustomer.getId());

	}

	@Override
	@Transactional
	public void deleteById(int theId) {
		
		//create query to get customer
		Query theQuery=
				entityManager.createQuery("delete from Customer where id= :customerId");
		
		theQuery.setParameter("customerId", theId);
		
		//delete the customer
		theQuery.executeUpdate();
	}

}
