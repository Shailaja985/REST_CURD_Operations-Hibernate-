package com.springboot.crud.cruddemoapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.springboot.crud.cruddemoapp.dao.CustomerDAO;
import com.springboot.crud.cruddemoapp.entity.Customer;

@Service
public class CustomerServiceHibernateImpl implements CustomerService {
	
	private CustomerDAO customerDAO;
	
	@Autowired
	public CustomerServiceHibernateImpl(@Qualifier("customerDAOJPAImpl") CustomerDAO customerDAO){
		this.customerDAO=customerDAO;
	}
	
	
	@Override
	@Transactional
	public List<Customer> findAll() {
		return customerDAO.findAll();
	}

	@Override
	@Transactional
	public Customer findById(int theId) {
		
		return customerDAO.findById(theId);
	}

	@Override
	@Transactional
	public void save(Customer customer) {
		customerDAO.save(customer);
	}

	@Override
	@Transactional
	public void deleteById(int theId) {
		customerDAO.deleteById(theId);
	}

}
