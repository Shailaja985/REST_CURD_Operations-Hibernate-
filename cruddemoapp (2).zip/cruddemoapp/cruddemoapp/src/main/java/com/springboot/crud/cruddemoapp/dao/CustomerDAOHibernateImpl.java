package com.springboot.crud.cruddemoapp.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.springboot.crud.cruddemoapp.entity.Customer;

@Repository
public class CustomerDAOHibernateImpl implements CustomerDAO {
	
	private EntityManager entityManager;
	
	@Autowired
	public CustomerDAOHibernateImpl(EntityManager entityManager){
		this.entityManager=entityManager;
	}
	
	@Override
	@Transactional
	public List<Customer> findAll() {
		
		//get current session
		Session currentSession=entityManager.unwrap(Session.class);
		
		
		//create query
		//Query<Customer> theQuery=currentSession.createQuery("from customer",customer.class);
		Query<Customer> theQuery=currentSession.createQuery("from Customer",Customer.class);
		
		//get the result set
		List<Customer> customers=theQuery.getResultList();
		
		//return the result
		return customers;
	}

	@Override
	public Customer findById(int theId) {

		//get the current session
		Session currentSession=entityManager.unwrap(Session.class);
		
		// get the employee
		Customer customer =currentSession.get(Customer.class, theId);
		
		//return the employee
		return customer;
	}

	@Override
	public void save(Customer customer) {
		
		//get the current session
		Session currentSession=entityManager.unwrap(Session.class);
		
		//save the customer
		currentSession.saveOrUpdate(customer);
		
		//return the save the customer
		//return customer;
	}

	@Override
	public void deleteById(int theId) {
		
		//get the current session 
		Session currentSession=entityManager.unwrap(Session.class);
		
		//get the customet need to delete 
		//Customer customer=currentSession.get(Customer.class,theId);
		Query theQuery=currentSession.createQuery("delete from Customer where id=:customerId"); 
		
		theQuery.setParameter("customerId", theId);
		
		theQuery.executeUpdate();
		//delete the 
		//currentSession.delete(theId);
		
		//return customer;
	}
}
