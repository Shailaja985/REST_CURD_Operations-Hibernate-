package com.springboot.crud.cruddemoapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.springboot.crud.cruddemoapp.dao.CustomerRepository;
import com.springboot.crud.cruddemoapp.entity.Customer;

@Service
public class CustomerServiceHibernateImpl implements CustomerService {
	
	private CustomerRepository customerRepository;
	
	@Autowired
	public CustomerServiceHibernateImpl(CustomerRepository customerRepository){
		this.customerRepository=customerRepository;
	}
	
	//no need to give @Transactional
	//since JpaRepository give us out of the box
	@Override
	public List<Customer> findAll() {
		return customerRepository.findAll();
	}

	@Override
	public Customer findById(int theId) {
		//return customerRepository.findById(theId);
		//select entire{customerRepository.findById(theId)}right click--refactor--extract local variable--give variable name
		
		Optional<Customer> result = customerRepository.findById(theId);
		//optional is useful to check for null
		
		Customer customer=null;
		if(result.isPresent()){
			customer= result.get();       //introduced in java 1.8
		}else{
			throw new RuntimeException("didn't find the employeeId "+theId);
		}
		return customer;
	}

	@Override
	public void save(Customer customer) {
		customerRepository.save(customer);
	}

	@Override
	public void deleteById(int theId) {
		customerRepository.deleteById(theId);
	}

}
