package com.springboot.crud.cruddemoapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.crud.cruddemoapp.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {
	//no need to write any code..Spring Data JPA give us all free
	//findAll() findById() ,save() ,deleteById()
}
